# Fixing the CSV path in Power BI Desktop

The message `DataSource.NotFound` with a path like `C:\Readmissions-PowerBI\data\ROC.csv` means the model is still using its template path instead of the folder where this ZIP was extracted.

## Preferred fix

1. Close Power BI Desktop without saving the failed refresh.
2. Extract a fresh copy of the complete ZIP to a normal local folder using **Extract All**. Do not open `Readmissions.pbip` from the ZIP preview. Keep the `data` folder beside `OPEN_REPORT.cmd`.
3. Run `OPEN_REPORT.cmd` from that extracted folder. The setup checks for all required CSV files, verifies the saved `DataFolder` parameter, and starts Power BI Desktop directly when it finds the app.
4. In Desktop, select **Refresh**. The source path should point to the extracted folder's `data` subfolder.

If Windows blocks `OPEN_REPORT.cmd`, right-click it, select **Properties**, and select **Unblock** if that option appears. You can also run the setup script from PowerShell opened in the extracted folder:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
& ".\Set-DataFolder.ps1"
```

Then open Power BI Desktop, choose **File > Open**, and select `Readmissions.pbip` from the extracted folder.

Do not open `Readmissions.pbip` directly on the first launch; doing so skips the path setup.

## Manual fix in Power BI Desktop

If the project is already open, go to **Transform data > Manage parameters**, select `DataFolder`, set its value to the full path of the extracted `data` folder (for example `D:\Reports\Readmissions-PowerBI\data`), then select **Close & Apply** and refresh. The value must be the folder containing `patients.csv`, `ROC.csv`, `CapacityAxis.csv`, `EffectSizes.csv`, `ModelMetrics.csv`, `Scenario.csv`, `Capacity.csv`, and `OddsRatios.csv`.

If Power BI has retained a failed refresh state, close without saving and use the preferred fix above. Re-extracting is safe; it does not alter the source dataset.
