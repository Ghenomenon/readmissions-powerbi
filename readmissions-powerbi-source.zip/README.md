# Readmissions Power BI project

## Rebuild the local patient data

This public repository contains the native report, model, measures, aggregate CSVs and preview images. The row-level patients.csv is excluded from Git.

1. Clone https://github.com/Ghenomenon/readmissions-case-study alongside this repository.
2. Download the UCI dataset and run that repository's pipeline as described in its README.
3. Install these requirements and prepare the local data:

```bash
pip install -r requirements.txt
python prepare_data.py --analysis-folder ../readmissions-case-study
```

## Open in Power BI Desktop on Windows

Open Readmissions.pbip from this repository's folder using Power BI Desktop. In Transform data > Manage Parameters, set DataFolder to the full path of this repository's data folder. Select Close & Apply and refresh. Windows may block the optional downloaded script launcher, so manual opening is the recommended route.

All report and semantic-model folders must remain beside Readmissions.pbip. If using a ZIP download, extract all files first.

## Seven report pages

- Patient overview: 69,987 selected index encounters, outcome, stay length and testing.
- Patient patterns and HbA1c: diagnosis and recorded testing variation.
- Model performance: fixed full-test model metrics, ROC, decile calibration and adjusted odds ratios.
- Follow-up capacity: test-cohort filtering, capacity selection, capture, precision and confusion counts.
- Subgroup performance: common selected-population threshold, race/age comparisons and recall intervals.
- Illustrative business case: capacity/scenario controls and hypothetical USD economics.
- Sources and methods: attribution, licence, cohort definitions and intended-use limits.

Page slicers apply locally. Clicking a chart mark filters the other visuals on that page. Clear selections using each slicer's eraser. Capacity defaults to 20% and financial scenario defaults to Base when no single selection is made. The default is a measure fallback, so the slicer displays All until a value is chosen. Choose one capacity and one scenario.

Original risk deciles stay fixed. Capacity thresholds rerank the selected test population. Threshold ties can flag slightly more patients than planned. The economics uses requested follow-ups per 1,000, as in the report; its workload assumption should be replaced by actual staffing costs. Fixed validation metrics and training odds ratios do not change with patient filters. There are no fabricated dates, trends or hospitals.

## Source and scope

UCI Diabetes 130-US Hospitals for Years 1999-2008 by John Clore, Krzysztof Cios, Jon DeShazo and Beata Strack. DOI https://doi.org/10.24432/C5230J. Dataset licensed under CC BY 4.0: https://creativecommons.org/licenses/by/4.0/. Data were cleaned, recoded, grouped and scored using the revised case-study pipeline. UCI and its creators do not endorse this work. Meridian is fictional; discovery is simulated; costs are hypothetical.

The locally regenerated analytical CSV has 69,987 records, with predictions only for 20,997 test encounters. It is not included in this public repository. Original patient and encounter identifiers are excluded. RowKey is a new sequential key. The native report displays aggregate results. Keep the analytical project private when sharing the public portfolio and use report screenshots or aggregate exports.

The model is a retrospective portfolio prototype, not clinically validated or approved for patient-care decisions. Any deployment needs local validation and governance review.

## Validation boundary

The data and calculations have been checked independently in Python, and report JSON is checked against Microsoft's published schemas. Power BI Desktop is not available in the build environment. This is a native PBIP/PBIR project, not a verified Desktop-exported PBIX. DAX execution, Power Query refresh and visual rendering require the final Desktop check. The PNG preview is an independently rendered layout preview, not a Power BI screenshot.
