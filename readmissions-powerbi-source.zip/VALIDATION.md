# Validation

- 69,987 analytical encounters reconcile to the revised cleaning pipeline.
- 20,997 test predictions match the revised scored export.
- Original patient and encounter identifiers are excluded.
- The 20% score quantile reproduces 4,200 flags, 697 true positives, 3,503 false positives, 1,189 false negatives and 15,608 true negatives.
- Hypothetical financial scenarios reconcile to independent Python calculations.
- 36 age/race/capacity combinations were checked for valid denominators and outcome capture.
- 100 report-definition JSON files and three PBIP/PBIR/PBISM entry files passed published Microsoft JSON schemas.
- All visual field references resolve to semantic-model columns or measures, and all visuals fit within their page bounds.
- Seven independent PNG layout previews were created for inspection.

Not executed here: Power BI Desktop opening, Power Query refresh, DAX engine execution, native visual rendering, Windows launcher execution and PBIX export. Final Desktop verification remains necessary.

## Desktop smoke check

1. Extract, run OPEN_REPORT.cmd, refresh and confirm the 69,987 patient count on page 1.
2. On capacity, clear filters and check 20,997 test patients, 4,200 flags and 37.0% recall.
3. Select 10% and 40% capacity and confirm workload/capture change.
4. Select an age group and confirm cards, charts, subgroup thresholds and source counts respond together.
5. On subgroup performance, verify African American and Caucasian rows and recall intervals at 20%.
6. On economics, confirm approximately $21,494 base net benefit per 1,000 at 20%; select Conservative and confirm negative benefit.
7. Confirm the scenario-comparison chart still displays all three cases after selecting one case.
8. Save as PBIX only after these checks.
