$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectPath = Join-Path $Root "Readmissions.pbip"

try {
    if ($Root -match '(?i)\\Temp\\[^\\]*\.zip\.[^\\]+\\') {
        throw "This project is running from Power BI's temporary ZIP view. Extract the complete ZIP to a normal folder first, then run OPEN_REPORT.cmd from the extracted folder."
    }
    & (Join-Path $Root "Set-DataFolder.ps1")
    if (-not (Test-Path -LiteralPath $ProjectPath -PathType Leaf)) {
        throw "Project file is missing: $ProjectPath. Extract the complete ZIP first."
    }

    # Find Power BI Desktop directly because Windows may not have a .pbip file association.
    $DesktopExe = (Get-Command "PBIDesktop.exe" -ErrorAction SilentlyContinue).Source
    if (-not $DesktopExe) {
        foreach ($Key in @(
            "HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\PBIDesktop.exe",
            "HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\PBIDesktop.exe",
            "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\PBIDesktop.exe"
        )) {
            if (Test-Path $Key) {
                $DesktopExe = (Get-Item $Key).GetValue("")
                if ($DesktopExe -and (Test-Path -LiteralPath $DesktopExe)) { break }
                $DesktopExe = $null
            }
        }
    }
    if (-not $DesktopExe) {
        $DesktopExe = Join-Path $env:ProgramFiles "Microsoft Power BI Desktop\bin\PBIDesktop.exe"
        if (-not (Test-Path -LiteralPath $DesktopExe)) { $DesktopExe = $null }
    }

    if ($DesktopExe) {
        Start-Process -FilePath $DesktopExe -ArgumentList ('"' + $ProjectPath + '"')
        Write-Host "Opening the report in Power BI Desktop."
    } else {
        Write-Host "Data path setup passed, but Power BI Desktop was not found automatically."
        Write-Host "Open Power BI Desktop, select File > Open, and choose: $ProjectPath"
        Read-Host "Press Enter to close this window"
    }
} catch {
    Write-Host "Could not open the report: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "You can still open Power BI Desktop and use File > Open with: $ProjectPath"
    exit 1
}
