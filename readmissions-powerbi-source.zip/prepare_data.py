from pathlib import Path
import pandas as pd, numpy as np, json, shutil, uuid
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve
import argparse
parser=argparse.ArgumentParser(description='Build the local patient CSV from the readmissions analysis outputs.')
parser.add_argument('--analysis-folder', type=Path, required=True)
args=parser.parse_args()
R=Path(__file__).resolve().parent;D=R/'data';D.mkdir(exist_ok=True)
base=args.analysis_folder.resolve();df=pd.read_csv(base/'data/processed/readmissions_clean.csv',low_memory=False);score=pd.read_csv(base/'outputs/powerbi/readmissions_scored.csv')
_,testidx=train_test_split(df.index,test_size=.3,stratify=df.readmitted_30,random_state=42)
assert len(score)==len(testidx)
assert (df.loc[testidx,'readmitted_30'].to_numpy()==score.readmitted_30.to_numpy()).all()
out=pd.DataFrame({'RowKey':np.arange(1,len(df)+1),'AgeBand':df.age_band,'AgeOrder':df.age_mid.astype(int),'AgeGroup':pd.cut(df.age_mid,[-1,59,79,120],labels=['Under 60','60-79','80+']).astype(str),'Gender':df.gender,'Race':df.race.replace({'AfricanAmerican':'African American','Other':'Other or unknown','Unknown':'Other or unknown'}),'Discharge':df.discharge_group,'Diagnosis':df.primary_diagnosis_group,'AdmissionType':df.admission_type.fillna('Other or unknown'),'LengthOfStay':df.time_in_hospital,'LOSGroup':pd.cut(df.time_in_hospital,[0,2,4,7,14],labels=['1-2 days','3-4 days','5-7 days','8-14 days']).astype(str),'PriorInpatient':df.number_inpatient,'PriorGroup':df.number_inpatient.clip(upper=4).astype(str).replace('4','4+'),'HbA1cTested':df.a1c_tested,'HbA1cStatus':df.a1c_tested.map({1:'Tested',0:'Not tested'}),'Readmitted':df.readmitted_30,'IsTest':0,'RiskScore':np.nan,'RiskDecile':np.nan,'ReferenceFlag20':np.nan})
out.loc[testidx,'IsTest']=1;out.loc[testidx,'RiskScore']=score.risk_score.to_numpy();out.loc[testidx,'RiskDecile']=score.risk_decile.to_numpy();out.loc[testidx,'ReferenceFlag20']=score.flag_follow_up.to_numpy()
# Remove source identifiers; the sequential key only resolves ranking ties.
out.to_csv(D/'patients.csv',index=False,float_format='%.12g')
print(f'Wrote {len(out):,} records to {D / "patients.csv"}; keep this file local.')
