$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataPath = Join-Path $Root "data"
$ModelPath = Join-Path $Root "Readmissions.SemanticModel\model.bim"
$RequiredFiles = @("patients.csv", "ROC.csv", "CapacityAxis.csv", "EffectSizes.csv", "ModelMetrics.csv", "Scenario.csv", "Capacity.csv", "OddsRatios.csv")

foreach ($File in $RequiredFiles) {
    $Candidate = Join-Path $DataPath $File
    if (-not (Test-Path -LiteralPath $Candidate -PathType Leaf)) {
        throw "Required data file is missing: $Candidate. Extract the complete ZIP and keep the data folder beside this script."
    }
}
if (-not (Test-Path -LiteralPath $ModelPath -PathType Leaf)) {
    throw "Semantic model file is missing: $ModelPath. Extract the complete ZIP before opening the report."
}

# Store the folder as a Power Query text parameter in the PBIP semantic model.
$Model = Get-Content -LiteralPath $ModelPath -Raw | ConvertFrom-Json
$Parameter = $Model.model.expressions | Where-Object { $_.name -eq "DataFolder" } | Select-Object -First 1
if ($null -eq $Parameter) {
    throw "The DataFolder parameter was not found in $ModelPath. Re-extract a fresh copy of the project."
}
$Escaped = $DataPath.Replace('"', '""')
$Parameter.expression = '"' + $Escaped + '" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'
$Json = $Model | ConvertTo-Json -Depth 100
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($ModelPath, $Json, $Utf8NoBom)

# Read the saved value back before opening Power BI; avoid silently using the template path.
$Check = Get-Content -LiteralPath $ModelPath -Raw | ConvertFrom-Json
$Saved = ($Check.model.expressions | Where-Object { $_.name -eq "DataFolder" } | Select-Object -First 1).expression
if ($Saved -notmatch [regex]::Escape($DataPath)) {
    throw "Could not verify the saved DataFolder parameter. Saved value: $Saved"
}
Write-Host "Data files verified: $DataPath"
Write-Host "DataFolder parameter saved and verified."
